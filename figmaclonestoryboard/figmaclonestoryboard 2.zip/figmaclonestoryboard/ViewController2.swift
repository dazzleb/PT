//
//  ViewController2.swift
//  figmaclonestoryboard
//
//  Created by 시혁 on 2023/02/09.
//

import UIKit

class ViewController2 : ViewController {
    

    @IBOutlet weak var CustomLabel: CustomLabel!
    
    @IBOutlet weak var CustomImgView: CustomImgView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}
