//
//  ViewController3.swift
//  figmaclonestoryboard
//
//  Created by 시혁 on 2023/02/09.
//

import Foundation
import UIKit
class ViewController3 : ViewController {
    @IBOutlet weak var CustomSmallView: CustomSmallView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}
