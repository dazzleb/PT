//
//  ViewController.swift
//  figmaclonestoryboard
//
//  Created by 시혁 on 2023/02/08.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var customView: CustomView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}

